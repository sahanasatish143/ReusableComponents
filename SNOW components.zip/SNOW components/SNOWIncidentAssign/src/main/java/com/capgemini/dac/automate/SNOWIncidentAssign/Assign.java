package com.capgemini.dac.automate.SNOWIncidentAssign;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

@Path("/assign_incident")
public class Assign 
{

	public static final Logger logger = Logger.getLogger(Assign.class.getName());
	ArrayList<String> fields = new ArrayList<String>();
	JSONObject jsonObject = null;
	String url = null;
	String uname = null;
	String pwd = null;
	String number = null;
	String resp = null;
	public Assign()
	{	

        try {
            InputStream inputStream = Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("logging.properties");
            LogManager.getLogManager().readConfiguration(inputStream);
            logger.info("Initializing logger");
        } catch (Exception e) {
            System.out.println("ERROR: While initializing logger");
            logger.severe("Error Message :"+e.getMessage());
            e.printStackTrace();
        }
     
	}
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
    public String rest(String incomingData) throws Exception 
    {
		try
        {
        jsonObject = new JSONObject(incomingData);
       	Iterator<String> it = jsonObject.keys();
     	while (it.hasNext()) 
		{  	
     	  String keys = it.next();
		  if (keys.equals("url")||keys.equals("username")||keys.equals("password")||keys.equals("number"))
		  {	
       		url = (String) jsonObject.get("url");
       		uname = (String) jsonObject.get("username");
       		pwd = (String) jsonObject.get("password");
       		number = (String) jsonObject.get("number");
       		logger.info("Incident number to assign : "+number);
       	  }
          else
          {
        	  fields.add(keys);
        	  logger.info(fields.toString());
     	  }
    	}
      }
      catch (Exception ex)
	  {
	    System.out.println(ex);
	  }     
		
		try
		{
			URL obj = new URL(url+"/api/now/table/incident?number="+number+"&sysparm_fields=sys_id,state");
			HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			String authString = uname + ":" + pwd;
			System.out.println("auth string: " + authString);
        String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(authString.getBytes());
        con.setRequestProperty("Authorization", basicAuth);
        System.out.println(basicAuth);                 
        
        int responseCode1 = con.getResponseCode();
        System.out.println("response code :" +responseCode1);
        logger.info("response code for GET :" + responseCode1);
        StringBuffer response = null;
        switch(responseCode1)
        { // success
        case 200: 
        {	
        	BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            response = new StringBuffer(); 

            while ((inputLine = in.readLine()) != null) 
            {
 			    response.append(inputLine);
 		    }
 		    in.close();
			; 
 		    
			int flag = 1;
 		    if(response.toString().contains("sys_id"))
 		    {
 		    	int index = response.toString().indexOf("sys_id");
 		    	String sys_id = response.toString().substring(index+9,index+41);
 		    	int fromindex = response.indexOf("state");
  	 		    String inc_state = response.substring(fromindex+8,fromindex+9);
				
  	 		    if(inc_state.equals("6") || inc_state.equals("7") )
  	 		    {
  	 		    	resp = "Incident "+number+" cannot be assigned becuse the incident might be resolved/closed";
 	 			    
  	 		    } 
  	 		    else
  	 		    {
  	 		    	for(int i=0;i<fields.size();i++)
  	 		    	{
  	 					String value = (String) jsonObject.get(fields.get(i));
  	 		    		if(value.isEmpty())
  	 		    		{
  	 		    			flag = 0;
  	 		    			break;
  	 		    		}
  	 		    	}
  	 		    	if(flag==0)  	 		    	
  	 		    		resp = "Null values provided. Check the parameters";
  	 		    	else
  	 		    		resp = assign(url,basicAuth,sys_id,fields);  	 		    	
  	 		    }
  	 		    	
 		    }   
 	        else
 	        {
 	            resp = "Incident "+number+" not found";
 	           
 	             	            
 	        }
 		    break;
        }
        case 401:
        {
        	resp = "Invalid user name or password";
        	break;
        }
        default:
        {
        	resp = "Unknown error";
        	break;
        }
        }
		}
		catch (MalformedURLException error) {
            // Output expected MalformedURLExceptions.
            resp = "Invalid request.Check the parameters";
        } catch (Exception exception) {
            // Output unexpected Exceptions.
        	resp = "Invalid request.Check the parameters";
        }
        HashMap<String, String> hash_map = new HashMap<String, String>();
      
        hash_map.put("response", resp);
        Gson gson = new Gson();
        String output1 = gson.toJson(hash_map);
        logger.info(output1);
        return output1;   
        	        
    }		
    private String assign(String url,String basicAuth,String sys_id,ArrayList<String> fields) throws IOException
    { 
        URL obj1 = new URL(url+"/api/now/table/incident/"+ sys_id );
        HttpsURLConnection conn = (HttpsURLConnection) obj1.openConnection();
        conn.setRequestMethod("PUT");
         
        conn.setRequestProperty("Authorization", basicAuth);
        System.out.println(basicAuth);
         
        conn.setDoOutput(true);
        DataOutputStream out = new DataOutputStream(conn.getOutputStream());
        out.write(getOutBytes(fields));
        out.flush();
        out.close();
        
        int responseCode1 = conn.getResponseCode();
        System.out.println("PUT Response Code for Incident Assign:: " + responseCode1); 
        logger.info("PUT Response Code for Incident Assign:: " + responseCode1);
        String resp1 = null;
        switch(responseCode1)
        {
          case 200 :
          { // success
            		  
            resp1 = "Incident assigned";
            break;
          }
          default:
          {
          	resp1 = "Check for parameters";            
             break;
          }        	 
        }

        return resp1;		
    }
    
    private byte[] getOutBytes(ArrayList<String> fields) 
    {
        JSONObject jsonObj = new JSONObject();
        
        try 
        {	int i =0;
        	while(i<fields.size())
        	{  	
        		String value = (String) jsonObject.get(fields.get(i));
        		jsonObj.put(fields.get(i),value);
        		i++;
        	}
                                 
        }  
        catch (Exception e) 
        {
            if (e != null) 
            {
                System.out.println("Json Exception Occured" + e.getMessage());
                logger.info("Json Exception :" + e.getMessage());
            }
        }
        byte[] out = jsonObj.toString().getBytes(StandardCharsets.UTF_8);
        return out;
    }     
}