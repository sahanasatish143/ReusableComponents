package com.capgemini.dac.automate.SNOWIncidentAttachFile;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

@Path("/attachfile_incident")
public class AttachFile 
{

	public static final Logger logger = Logger.getLogger(AttachFile.class.getName());
	public AttachFile()
	{	

        try {
            InputStream inputStream = Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("logging.properties");
            LogManager.getLogManager().readConfiguration(inputStream);
            logger.info("Initializing logger");
        } catch (Exception e) {
            System.out.println("ERROR: While initializing logger");
            logger.severe("Error Message :"+e.getMessage());
            e.printStackTrace();
        }
     
	}
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String rest(InputStream incomingData) throws Exception 
    {
        JSONObject json = new JSONObject();
        String res = null; 
        res = IOUtils.toString(incomingData, "UTF-8");
        JSONParser parser = new JSONParser();            
        json = (JSONObject) parser.parse(res);
         
        String url=(String) json.get("url");
    	String uname=(String) json.get("username");
    	String pwd=(String) json.get("password");
         
        String inc_number = (String) json.get("number"); 
        System.out.println("value: " + inc_number);
        logger.info("number: " + inc_number);
        
		String file = (String) json.get("file"); 
        System.out.println("value1: " + file);         
        logger.info("value1: " + file); 
                
        File file_obj = new File(file);
        String name =file_obj.getName();
        
        String resp = null;
        try
        {
        URL obj = new URL(url+"/api/now/table/incident?number="+ inc_number+"&sysparm_fields=sys_id,state");
        HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        String authString = uname + ":" + pwd;
        System.out.println("auth string: " + authString);
        String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(authString.getBytes());
        con.setRequestProperty("Authorization", basicAuth);
        System.out.println(basicAuth);                 
         
        int responseCode = con.getResponseCode();
        System.out.println("response code for getting sys_id :" +responseCode);
        logger.info("response code for getting sys_id :" +responseCode);
        
        switch(responseCode)
        {
        case 200 :
        { // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer(); 

            while ((inputLine = in.readLine()) != null) 
			{
 				response.append(inputLine);
 			}
 			in.close();
 			 
 			resp = response.toString();
 			if(resp.contains("sys_id"))
 			{
 			    int index = resp.indexOf("sys_id");
	 		    String sys_id = resp.substring(index+9,index+41);
	 		    
	 		    int fromindex = resp.indexOf("state");
 	 		    String inc_state = resp.substring(fromindex+8,fromindex+9);
				
 	 		    if(inc_state.equals("6") || inc_state.equals("7"))
 	 		    {
 	 		    	resp = "File cannot be attached to this incident";
	 			    System.out.println(resp);
	 			   logger.info(resp);
 	 		    }
	 		    else
	 		    {
	 		    	if(file_obj.exists())	 		    		
	 		    		resp = attach(url,basicAuth,sys_id,name,file_obj); 
	 		    	else 
	 		    		resp = "Invalid file ";
	 		    }
 			}
 			else
 			{
 				resp = "Incident "+inc_number+" not found";
 				System.out.println(resp);
 				logger.info(resp);
 			} 
 			break;
        }
        case 401 :
        {
        	resp = "Invalid user name or password";
        	break;
        }
        default:
        {
        	resp = "Check for parameters";
        }
       }  
        }
        catch (MalformedURLException error) {
            // Output expected MalformedURLExceptions.
            resp = "Invalid request.Check the parameters";
        } catch (Exception exception) {
            // Output unexpected Exceptions.
        	resp = "Invalid request.Check the parameters";
        }
        HashMap<String, String> hash_map = new HashMap<String, String>();
    
        hash_map.put("response", resp);
        Gson gson = new Gson();
        String output1 = gson.toJson(hash_map);
        return output1;
    } 		
    
	private String attach(String url,String basicAuth,String sys_id,String file_name,File file) throws IOException
    {
		String resp1 = null;
	
		URL obj = new URL(url+"/api/now/attachment/file?table_name=incident&table_sys_id="+sys_id+"&file_name="+file_name);
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
         
		con.setRequestProperty("Authorization", basicAuth);
        con.setRequestProperty("Content-Type", "application/json"); 
        con.setDoOutput(true);
         
        DataOutputStream outputStream = new DataOutputStream(con.getOutputStream());       
                                         
        byte[] allBytes = new byte[(int) file.length()];
        FileInputStream fileInputStream = new FileInputStream(file);                
        fileInputStream.read(allBytes);
        outputStream.write(allBytes);
        fileInputStream.close();
        System.out.println(allBytes);
         
        
        StringBuffer response = null;
        int responseCode = con.getResponseCode();
        System.out.println("POST Response Code for Attach file to an Incident :: " + responseCode);
        logger.info("POST Response Code for Attach file to an Incident :: " + responseCode);
        
       switch(responseCode)
       {
       case 201:
       {
    	   // success
            BufferedReader bin = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            response = new StringBuffer(); 

            while ((inputLine = bin.readLine()) != null) 
            {
                response.append(inputLine);
            }
            bin.close();
            resp1 = "File attached to the incident";
            System.out.println(resp1);
            logger.info("response for Attach file :" +resp1);
            break;
        }
        default :
        {
        	resp1 = "POST request not worked";
        }
       }	
		      
    
       return resp1;   
    }
}