package com.capgemini.dac.automate.SNOWIncidentDownload;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;


@Path("/attachment_download")
public class Download
{
	public static final Logger logger = Logger.getLogger(Download.class.getName());
	String resp = null;
	public Download()
	{
		try {
            InputStream inputStream = Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("logging.properties");
            LogManager.getLogManager().readConfiguration(inputStream);
            logger.info("Initializing logger");
        } catch (Exception e) {
            System.out.println("ERROR: While initializing logger");
            logger.severe("Error Message :"+e.getMessage());
            e.printStackTrace();
        }

	}
	
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public String rest(InputStream incomingData) throws Exception 
    {
    	
        JSONObject json = new JSONObject();
        String res = null; 
        res = IOUtils.toString(incomingData, "UTF-8");
        JSONParser parser = new JSONParser();            
        json = (JSONObject) parser.parse(res);
        
        String url=(String) json.get("url");
    	String uname=(String) json.get("username");
    	String pwd=(String) json.get("password");
        
        String inc_number = (String) json.get("number");
		System.out.println("number: " + inc_number);
		logger.info("number: " + inc_number);
		
		String file_path = (String) json.get("path");
		logger.info("file_download_loc: " + file_path);
	  try
	  {
		URL obj = new URL(url+"/api/now/table/incident?number="+ inc_number+"&sysparm_fields=sys_id,state");
        HttpsURLConnection conn = (HttpsURLConnection) obj.openConnection();
        conn.setRequestMethod("GET");
        String authString = uname + ":" + pwd;
        
        String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(authString.getBytes());
        conn.setRequestProperty("Authorization",basicAuth);
        System.out.println(basicAuth);                 
  
        int responseCode = conn.getResponseCode();
        System.out.println("response code :" +responseCode);
        logger.info("Incident query response code :" +responseCode);
        
        String output1 = null;
        switch(responseCode)
        {
        case 200:
        
        { // success
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer(); 

            while ((inputLine = in.readLine()) != null) 
			{
 				response.append(inputLine);
 			}
 			in.close();
 			 
 			
 						
			if (response.toString().contains("sys_id"))
 			{      
				int index = response.toString().indexOf("sys_id");
	 			String sys_id = response.toString().substring(index+9,index+41);
	 			
	 			int fromindex = response.toString().indexOf("state");
	 		    String inc_state = response.toString().substring(fromindex+8,fromindex+9);
				

                if(inc_state.equals("6") || inc_state.equals("7") ) {
                
                   resp = "Files cannot be downloaded from this incident";
                   System.out.println(resp);
                logger.info(resp);
                }
               else
               
            	   resp = attachment_query(url,basicAuth,sys_id,file_path);
 			}
 			else
 			{
 				resp = "Incident "+inc_number+" not found";
 				System.out.println(resp);
 				logger.info(resp);
 			}    
			break;
 		}
        case 401:
        {
        	resp = "Invalid user name or password";
        	break;
        }
        default:
        {
        	resp = "Unknown error";
        	break;
        }
        }
	  }
	  catch (MalformedURLException error) {
          // Output expected MalformedURLExceptions.
          resp = "Invalid request.Check the parameters";
      } catch (Exception exception) {
          // Output unexpected Exceptions.
      	resp = "Invalid request.Check the parameters";
      }
         HashMap<String, String> hash_map = new HashMap<String, String>();
         hash_map.put("response", resp);
         Gson gson = new Gson();
         String output1 = gson.toJson(hash_map);
         logger.info(output1);
         return output1;
    }
    
    
	public String attachment_query(String url,String basicAuth,String sys_id,String file_path) throws IOException, ParseException
    {
        URL obj = new URL(url+"/api/now/attachment?table_name=incident&table_sys_id="+sys_id);
        HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
              
        con.setRequestProperty("Authorization", basicAuth);
                     
        int responseCode = con.getResponseCode();
        System.out.println("response code :" +responseCode);
        logger.info("Attachment query response code :" +responseCode);
        String resp1 = null;
        switch(responseCode)
        {
        case 200:
        {// success
            BufferedReader bin = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder(); 

            while ((inputLine = bin.readLine()) != null) 
 			{
      			response.append(inputLine);
      		}
      		bin.close();
      		
            if(response.toString().contains("sys_id"))
            {
                String[] array = response.toString().split("},");
          		int length = array.length;
          		for(int i=0;i<length;i++)
          		{       			
          			System.out.println(array[0]);
          			int fromIndex = array[0].indexOf("sys_id");          			
                    String att_sys_id = array[0].substring(fromIndex+9,fromIndex+41);
                    System.out.println(att_sys_id);
                    String[] arr = array[0].split("file_name");
                    String[] arr1 = arr[1].split(",");
          	        String file_name = arr1[0].replaceAll("[^a-zA-Z0-9.]","");  
          	        System.out.println(file_name);
   	 		        resp1 = download(url,basicAuth,att_sys_id,file_name,file_path);
          	    }          			
          	}
            else
            {
            	resp1 = "No attachment found";
                System.out.println(resp1);
                logger.info(resp1);
            }
            break;
 		}
 		default:
 		{
 			resp1 = "Check for parameters";
 			break;
  		}
        }
        
        return resp1;
 	}
	
    private String download(String url,String basicAuth,String att_sys_id,String file_name,String file_path) throws IOException
    {
    	URL obj = new URL(url+"/api/now/attachment/"+att_sys_id+"/file");
    	System.out.println(obj);
        HttpsURLConnection connection = (HttpsURLConnection) obj.openConnection();
		connection.setRequestMethod("GET");     
        connection.setRequestProperty("Authorization", basicAuth);
       
        int responseCode = connection.getResponseCode();
        System.out.println("GET Response Code for Downloading attachment :: " + responseCode); 
        logger.info("GET Response Code for Downloading attachment :: " + responseCode); 
        String resp2 = null;
        
       switch(responseCode)
       {
       case 200:
       { 
    	   	File f = new File(file_path);
    	   	if(f.exists())
    	   	{
    	   		InputStream input = connection.getInputStream();
    	   		byte[] buffer = new byte[102400];
    	   		int n;
        	 
    	   		OutputStream output = new FileOutputStream(file_path+file_name);
    	   		while((n=input.read(buffer)) != -1)
    	   		{        		
    	   			output.write(buffer, 0, n);
    	   		}
    	   		output.close();    	   	
    	   		resp2 = "File downloaded";
    	   	}
    	   	else
    	   	{
    	   		resp2 = "Invalid download path provided";
    	   	}
        	break;
        }
        default:
        {
            resp2 = "GET request not worked";
        }      
    } 
       return resp2;
    }
}