package com.capgemini.dac.automate.SNOWIncidentQuery;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import com.google.gson.Gson;

@Path("/query_incident")
public class Query 
{
	public static final Logger logger = Logger.getLogger(Query.class.getName());
	
	ArrayList<String> fields = new ArrayList<String>();
	String url = null;
	String uname = null;
	String pwd = null;
	String resp = null;
	JSONObject jsonObject = null;
	String query = "";
	String outfile = null;
	
	public Query()
	{
		try 
		{
			InputStream inputStream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("logging.properties");
			LogManager.getLogManager().readConfiguration(inputStream);
			logger.info("Initializing logger");
		} 
		catch (Exception e) 
		{
			System.out.println("ERROR: While initializing logger");
			logger.severe("Error Message :" +e.getMessage());
			e.printStackTrace();    
		}
	
	}
	@POST   
	@Produces(MediaType.APPLICATION_JSON)	
	public String rest(String incomingData) throws Exception 
	{ 
		try 
		{
			jsonObject = new JSONObject(incomingData);
			Iterator<String> it = jsonObject.keys();
			while (it.hasNext()) 
			{  	
				String keys = it.next();
				if (keys.equals("url")||keys.equals("username")||keys.equals("password")||keys.equals("out_file"))
				{	
					url = (String) jsonObject.get("url");
					uname = (String) jsonObject.get("username");
					pwd = (String) jsonObject.get("password");
					outfile = (String) jsonObject.get("out_file");
				}
				else
				{
					fields.add(keys);
					logger.info(fields.toString());
				}
			}
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
	
		int size = fields.size();
		int flag=1;
		String value = null;
		for(int i=0;i<size;i++)
		{
			value = (String) jsonObject.get(fields.get(i));
			
			if(value.isEmpty())
	    		{
					flag = 0;
	    			break;
	    		}
			else
			{
			if(i==(size-1))
    			query = query+fields.get(i)+"="+value;
    		else 
    		{
    			query = query+fields.get(i)+"="+'"'+value+"&";
    		}
			}
		}
	    	
		if(flag==0)  	 		    	
			 resp = "Null values provided. Check the parameters";
	      else 		
	      { 
	try
	{
		URL obj = new URL(url+"/api/now/table/incident?sysparm_query="+query);
		
	
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		String authString = uname + ":" + pwd;
		System.out.println("auth string: " + authString);
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(authString.getBytes());
		con.setRequestProperty("Authorization", basicAuth);
		System.out.println(basicAuth);
             
		StringBuffer response =null;
		int responseCode = con.getResponseCode();
		System.out.println("GET Response Code for Incident Query:: " + responseCode); 
		logger.info("GET Response Code for Incident Query:: " + responseCode);
		
		
		switch(responseCode) 
		{
			case 200:
			{	
				BufferedReader bin = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                response = new StringBuffer();

 

                while ((inputLine = bin.readLine()) != null) {
                    response.append(inputLine);
                }
                bin.close();      
                System.out.println(response.toString());
                logger.info(response.toString());
                System.out.println(response.toString());

				if(response.toString().contains("number"))
				{  
					File myObj = new File(outfile);
					FileWriter fw=new FileWriter(myObj); 
					fw.write(response.toString());    
					fw.close();   
					resp = "Query response stored in the file "+myObj;
				}	        	
				
				else
				{
					resp = "No data found with given query";          	
				}
				break;
            }
			case 401:
			{
				resp = "Invalid user name or password";
				break;
			}
			default:
			{
				resp = "Unknown error";
				break;
			}
		}
	}
	catch (MalformedURLException error) {
        // Output expected MalformedURLExceptions.
        resp = "Invalid request.Check the parameters";
    } catch (Exception exception) {
        // Output unexpected Exceptions.
    	resp = "Invalid request.Check the parameters";
    }
	      }
	HashMap<String, String> hash_map = new HashMap<String, String>();
        hash_map.put("response", resp);
        Gson gson = new Gson();
        String output1 = gson.toJson(hash_map);
        logger.info(output1);
        return output1;     
	}   
}